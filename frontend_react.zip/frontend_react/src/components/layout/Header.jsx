import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import './Header.css';

const Header = ({ userRole = null, showNavigation = true }) => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  const getNavigationByRole = () => {
    if (!user || !showNavigation) return null;

    switch (user.role) {
      case 'entrenador':
        return (
          <>
            <Link to="/entrenador">INICIO</Link>
            <Link to="/listados">LISTADO</Link>
            <Link to="/convocatorias">CONVOCATORIAS</Link>
            <Link to="/categorias">CATEGORIA</Link>
            <Link to="/calendario">CALENDARIO</Link>
          </>
        );
      case 'jugador':
        return (
          <>
            <Link to="/jugador">INICIO</Link>
            <Link to="/convocatorias">CONVOCATORIAS</Link>
            <Link to="/calendario">CALENDARIO</Link>
          </>
        );
      case 'acudiente':
        return (
          <>
            <Link to="/acudiente">INICIO</Link>
            <Link to="/convocatorias">CONVOCATORIAS</Link>
            <Link to="/calendario">CALENDARIO</Link>
          </>
        );
      default:
        return <Link to="/">INICIO</Link>;
    }
  };

  const getHeaderIcons = () => {
    if (!user) return null;

    return (
      <div className="header-icons">
        {user.role === 'entrenador' && (
          <Link to="/calendario">
            <img
              src="/image/icon-calendar.png"
              alt="Calendario"
            />
          </Link>
        )}
        <Link to="/perfil">
          <img
            src="/image/icon-profile.png"
            alt="Perfil"
          />
        </Link>
      </div>
    );
  };

  return (
    <header>
      <div className="logo">
        <Link to="/">
          <img
            src="/image/logo-light-transparent.png"
            alt="Futsal Life Logo"
          />
        </Link>
      </div>

      {user ? (
        <>
          <h1>¡Bienvenido a Futsal Life La Calera!</h1>
          <nav>{getNavigationByRole()}</nav>
          {getHeaderIcons()}
          <div className="contact-info">
            <button
              onClick={handleLogout}
              className="contact-button">
              Cerrar Sesión
            </button>
          </div>
        </>
      ) : (
        <>
          <h1>¡Bienvenido a Futsal Life La Calera!</h1>
          <div className="contact-info">
            <Link
              to="/login"
              className="contact-button">
              Registrarse/Iniciar Sesión
            </Link>
          </div>
        </>
      )}
    </header>
  );
};

export default Header;
