import React from 'react';
import './Footer.css';

const Footer = () => {
  return (
    <footer>
      <div className="footer-container">
        <div className="footer-section">
          <h3>¡Estamos aquí para ayudarte!</h3>
          <p>
            📅 <strong>Lunes, miércoles y Viernes:</strong> 4:30 PM - 7:00 PM
          </p>
        </div>

        <div className="footer-section">
          <h3>
            <img
              src="/image/logo-light-transparent.png"
              alt="Logo"
            />
          </h3>
          <div className="social-icons">
            <a
              href="#"
              aria-label="Facebook">
              <img
                src="/image/faceb.png"
                alt="Facebook"
              />
            </a>
            <a
              href="#"
              aria-label="WhatsApp">
              <img
                src="/image/whats.png"
                alt="WhatsApp"
              />
            </a>
            <a
              href="#"
              aria-label="Instagram">
              <img
                src="/image/insta.png"
                alt="Instagram"
              />
            </a>
          </div>
        </div>

        <div className="footer-section contact-us">
          <h3>
            Correo institucional:
            <br />
            contactenos@lacalera-cundinamarca.gov.co
            <br />
            notificacionjudicial@lacalera-cundinamarca.gov.co
          </h3>
        </div>
      </div>

      <div className="footer-bottom">
        <p>Asesorado, diseñado y desarrollado por: NYS. © 2024</p>
        <p>
          <a href="#">Política de Privacidad</a> |{' '}
          <a href="#">Términos y Condiciones</a>
        </p>
      </div>
    </footer>
  );
};

export default Footer;
