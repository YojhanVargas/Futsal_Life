import React from 'react';
import { Navigate, Outlet } from 'react-router-dom';
import { useAuth } from "../../context/AuthContext.jsx";
import Layout from "../layout/Layout.jsx";
const ProtectedRoute = ({ allowedRoles }) => {
  const { user, isLoading, isAuthenticated } = useAuth();

  if (isLoading) {
    return <div>Cargando...</div>; // O un componente de spinner/loading
  }

  if (!isAuthenticated) {
    return (
      <Navigate
        to="/login"
        replace
      />
    );
  }

  if (allowedRoles && !allowedRoles.includes(user?.role)) {
    // Si el rol no está permitido, redirigir a una página de no autorizado o a la página de inicio
    // Por ahora, redirigimos a la página de inicio del rol del usuario o a la raíz
    const homePath = user?.role ? `/${user.role}` : '/';
    return (
      <Navigate
        to={homePath}
        replace
      />
    );
  }

  return (
    <Layout>
      <Outlet />
    </Layout>
  );
};

export default ProtectedRoute;
