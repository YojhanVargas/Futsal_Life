import React from 'react';
import { Link } from 'react-router-dom';
import Layout from "../../components/layout/Layout.jsx";

const NotFoundPage = () => {
  return (
    <Layout>
      <div style={{ textAlign: 'center', marginTop: '50px' }}>
        <h1>404 - Página No Encontrada</h1>
        <p>Lo sentimos, la página que estás buscando no existe.</p>
        <Link to="/">Volver al Inicio</Link>
      </div>
    </Layout>
  );
};

export default NotFoundPage;
