import React from 'react';
import Layout from '../../components/Layout/Layout';

const CategoriasPage = () => {
  return (
    <Layout>
      <div>
        <h1>Categorías</h1>
        <p>Información sobre las diferentes categorías de la escuela.</p>
        {/* Lógica para cargar y mostrar categorías */}
      </div>
    </Layout>
  );
};

export default CategoriasPage;
