import React from 'react';
import Layout from '../../components/Layout/Layout';

const CalendarioPage = () => {
  return (
    <Layout>
      <div>
        <h1>Calendario de Partidos y Eventos</h1>
        <p>Consulta el calendario completo de la escuela.</p>
        {/* Lógica para cargar y mostrar el calendario */}
      </div>
    </Layout>
  );
};

export default CalendarioPage;
