import React from 'react';
import { useAuth } from '../../context/AuthContext.jsx'; // 1. Usamos el hook, la forma correcta.
import Layout from '../../components/layout/Layout.jsx';   // 2. Corregí la ruta a 'layout' en minúscula.

const ProfilePage = () => {
  // ...lógica...
  return (
    // Se devuelve solo el contenido específico de la página
    <div>
      <h2>Mi Perfil</h2>
      <p>Nombre: {user.nombre}</p>
    </div>
  );
};

  

export default ProfilePage;