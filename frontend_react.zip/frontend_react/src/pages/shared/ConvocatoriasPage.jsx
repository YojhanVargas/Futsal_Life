import React from 'react';
import Layout from '../../components/Layout/Layout';

const ConvocatoriasPage = () => {
  return (
    <Layout>
      <div>
        <h1>Convocatorias</h1>
        <p>Consulta las próximas convocatorias y eventos.</p>
        {/* Lógica para cargar y mostrar convocatorias */}
      </div>
    </Layout>
  );
};

export default ConvocatoriasPage;
