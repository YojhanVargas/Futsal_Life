import React from 'react';
import Layout from '../../components/Layout/Layout';

// Este es un componente genérico para páginas de listados.
// Podrías pasarle props para especificar qué tipo de listado mostrar (ej. jugadores, equipos, etc.)
const ListadosPage = ({ tipoListado }) => {
  return (
    <Layout>
      <div>
        <h1>Listados</h1>
        <p>Aquí se mostrarán los listados de {tipoListado || 'elementos'}.</p>
        {/* Lógica para cargar y mostrar listados */}
      </div>
    </Layout>
  );
};

export default ListadosPage;
