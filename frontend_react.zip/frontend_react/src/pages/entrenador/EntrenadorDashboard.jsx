import React from 'react';
import Layout from '../../components/Layout/Layout';
import './EntrenadorDashboard.css'; // Import the CSS file

const EntrenadorDashboard = () => {
  return (
    <Layout>
      <div className="entrenador-dashboard">
        <h1>Dashboard del Entrenador</h1>

        <div className="dashboard-content">
          <div className="dashboard-card">
            <h2>Gestión de Equipos</h2>
            <p>Administra tus equipos, jugadores y categorías.</p>
            <ul>
              <li>
                <a href="#">Ver mis equipos</a>
              </li>
              <li>
                <a href="#">Registrar nuevo jugador</a>
              </li>
              <li>
                <a href="#">Asignar jugadores a categorías</a>
              </li>
            </ul>
          </div>

          <div className="dashboard-card">
            <h2>Planificación de Entrenamientos</h2>
            <p>Crea y gestiona sesiones de entrenamiento.</p>
            <ul>
              <li>
                <a href="#">Programar nuevo entrenamiento</a>
              </li>
              <li>
                <a href="#">Ver calendario de entrenamientos</a>
              </li>
              <li>
                <a href="#">Registrar asistencia</a>
              </li>
            </ul>
          </div>

          <div className="dashboard-card">
            <h2>Convocatorias</h2>
            <p>Gestiona las convocatorias para partidos y eventos.</p>
            <ul>
              <li>
                <a href="#">Crear nueva convocatoria</a>
              </li>
              <li>
                <a href="#">Ver convocatorias activas</a>
              </li>
              <li>
                <a href="#">Confirmar asistencia de jugadores</a>
              </li>
            </ul>
          </div>

          <div className="dashboard-card">
            <h2>Comunicación</h2>
            <p>Envía mensajes y notificaciones.</p>
            <ul>
              <li>
                <a href="#">Enviar mensaje a equipo</a>
              </li>
              <li>
                <a href="#">Enviar mensaje a acudientes</a>
              </li>
              <li>
                <a href="#">Ver notificaciones</a>
              </li>
            </ul>
          </div>

          <div className="dashboard-card">
            <h2>Mi Perfil</h2>
            <p>Actualiza tu información personal y preferencias.</p>
            <ul>
              <li>
                <a href="#">Editar perfil</a>
              </li>
              <li>
                <a href="#">Cambiar contraseña</a>
              </li>
            </ul>
          </div>

          <div className="dashboard-card">
            <h2>Recursos y Documentos</h2>
            <p>Accede a material de entrenamiento y documentos importantes.</p>
            <ul>
              <li>
                <a href="#">Biblioteca de ejercicios</a>
              </li>
              <li>
                <a href="#">Reglamento interno</a>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default EntrenadorDashboard;
