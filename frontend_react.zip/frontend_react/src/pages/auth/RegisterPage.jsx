import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from "../../context/AuthContext.jsx"; // CORRECTO
import Layout from "../../components/layout/Layout.jsx";  // CORRECTO
// Ya no necesitas importar 'registerUser' aquí.
import './AuthForm.css';

const RegisterPage = () => {
  // El manejo del estado está perfecto. No se toca.
  const [nombre, setNombre] = useState('');
  const [cedula, setCedula] = useState('');
  const [telefono, setTelefono] = useState('');
  const [contrasena, setContrasena] = useState('');
  const [confirmContrasena, setConfirmContrasena] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [rol, setRol] = useState('Jugador');
  const [error, setError] = useState('');
  const [successMessage, setSuccessMessage] = useState(''); // Para un mejor feedback al usuario
  const [loading, setLoading] = useState(false);

  // --- CORRECCIÓN IMPORTANTE ---
  // Extraemos la función 'register' del contexto, no 'login'.
  const { register } = useAuth();
  const navigate = useNavigate();

  // --- LÓGICA DE REGISTRO SIMPLIFICADA ---
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (contrasena !== confirmContrasena) {
      setError('Las contraseñas no coinciden.');
      return;
    }
    setError('');
    setSuccessMessage('');
    setLoading(true);

    try {
      // 1. Prepara los datos del nuevo usuario
      const newUser = { nombre, cedula, telefono, contrasena, rol };

      // 2. Llama a la función 'register' del contexto
      const result = await register(newUser);

      // 3. Revisa si tuvo éxito y actúa en consecuencia
      if (result.success) {
        setSuccessMessage('¡Registro exitoso! Redirigiendo al login...');
        // Espera un momento para que el usuario vea el mensaje y luego redirige
        setTimeout(() => {
          navigate('/login');
        }, 2000);
      } else {
        setError(result.message || 'Error en el registro.');
      }
    } catch (err) {
      console.error("Error capturado en el formulario de registro:", err);
      setError('Ocurrió un error inesperado. Intenta de nuevo.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Layout>
      <div className="auth-form-container">
        <div className="auth-form-wrapper">
          <h2>Registrarse</h2>
          <form onSubmit={handleSubmit}>
            {/* ... tu JSX del formulario (esto no cambia y está bien) ... */}
            <div className="form-group">
              <label htmlFor="nombre">Nombre Completo:</label>
              <input type="text" id="nombre" value={nombre} onChange={(e) => setNombre(e.target.value)} required placeholder="Tu nombre completo"/>
            </div>
            <div className="form-group">
              <label htmlFor="cedula">Cédula:</label>
              <input type="text" id="cedula" value={cedula} onChange={(e) => setCedula(e.target.value)} required placeholder="Tu número de cédula"/>
            </div>
            <div className="form-group">
              <label htmlFor="telefono">Teléfono:</label>
              <input type="text" id="telefono" value={telefono} onChange={(e) => setTelefono(e.target.value)} required placeholder="Tu número de teléfono"/>
            </div>
            <div className="form-group">
              <label htmlFor="contrasena">Contraseña:</label>
              <div className="password-container">
                <input type={showPassword ? 'text' : 'password'} id="contrasena" value={contrasena} onChange={(e) => setContrasena(e.target.value)} required placeholder="Crea una contraseña"/>
                <button type="button" className="toggle-password" onClick={() => setShowPassword(!showPassword)}>{showPassword ? '🙈' : '👁️'}</button>
              </div>
            </div>
            <div className="form-group">
              <label htmlFor="confirmContrasena">Confirmar Contraseña:</label>
              <div className="password-container">
                <input type={showConfirmPassword ? 'text' : 'password'} id="confirmContrasena" value={confirmContrasena} onChange={(e) => setConfirmContrasena(e.target.value)} required placeholder="Confirma tu contraseña"/>
                <button type="button" className="toggle-password" onClick={() => setShowConfirmPassword(!showConfirmPassword)}>{showConfirmPassword ? '🙈' : '👁️'}</button>
              </div>
            </div>
            <div className="form-group">
              <label htmlFor="rol">Rol:</label>
              <select id="rol" value={rol} onChange={(e) => setRol(e.target.value)} required>
                <option value="Jugador">Jugador</option>
                <option value="Acudiente">Acudiente</option>
              </select>
            </div>

            {error && <p className="error-message">{error}</p>}
            {successMessage && <p className="success-message">{successMessage}</p>}
            
            <button type="submit" className="submit-button" disabled={loading}>
              {loading ? 'Registrando...' : 'Registrarse'}
            </button>
          </form>
          <p className="switch-form-link">
            ¿Ya tienes una cuenta? <Link to="/login">Inicia sesión aquí</Link>
          </p>
        </div>
      </div>
    </Layout>
  );
};

export default RegisterPage;