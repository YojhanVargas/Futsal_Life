import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from "../../context/AuthContext.jsx"; // CORRECTO
import Layout from "../../components/layout/Layout.jsx";  // CORRECTO
// Ya no necesitas importar 'loginUser' aquí, el contexto lo hace.
import './AuthForm.css';

const LoginPage = () => {
  const [cedula, setCedula] = useState('');
  const [contrasena, setContrasena] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  
  // Obtienes la función 'login' del contexto. ¡Perfecto!
  const { login } = useAuth(); 
  const navigate = useNavigate();

  // --- LÓGICA DE LOGIN SIMPLIFICADA ---
const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const result = await login({ cedula, contrasena });

      if (result.success) {
        navigate('/');
      } else {
        setError(result.message || 'Error al iniciar sesión.');
      }
    } catch (err) { // <--- El 'err' que estaba subrayado
      // --- ESTA ES LA CORRECCIÓN ---
      // Lo mostramos en la consola para que tú como desarrollador veas el problema.
      console.error("Error capturado en el formulario de login:", err); 
      
      // Le mostramos un mensaje genérico al usuario.
      setError('Ocurrió un error inesperado. Intenta de nuevo.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Layout>
      <div className="auth-form-container">
        <div className="auth-form-wrapper">
          <h2>Iniciar Sesión</h2>
          <form onSubmit={handleSubmit}>
            {/* ... tu JSX del formulario (esto no cambia y está bien) ... */}
            <div className="form-group">
              <label htmlFor="cedula">Cédula:</label>
              <input
                type="text"
                id="cedula"
                value={cedula}
                onChange={(e) => setCedula(e.target.value)}
                required
                placeholder="Tu número de cédula"
              />
            </div>
            <div className="form-group">
              <label htmlFor="contrasena">Contraseña:</label>
              <div className="password-container">
                <input
                  type={showPassword ? 'text' : 'password'}
                  id="contrasena"
                  value={contrasena}
                  onChange={(e) => setContrasena(e.target.value)}
                  required
                  placeholder="Tu contraseña"
                />
                <button
                  type="button"
                  className="toggle-password"
                  onClick={() => setShowPassword(!showPassword)}>
                  {showPassword ? '🙈' : '👁️'}
                </button>
              </div>
            </div>
            {error && <p className="error-message">{error}</p>}
            <button
              type="submit"
              className="submit-button"
              disabled={loading}>
              {loading ? 'Ingresando...' : 'Iniciar Sesión'}
            </button>
          </form>
          <p className="switch-form-link">
            ¿No tienes una cuenta? <Link to="/register">Regístrate aquí</Link>
          </p>
        </div>
      </div>
    </Layout>
  );
};

export default LoginPage;