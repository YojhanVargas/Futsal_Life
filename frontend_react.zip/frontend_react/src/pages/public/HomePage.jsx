import React, { useState, useEffect } from 'react';
import Layout from "../../components/layout/Layout.jsx";
import './HomePage.css'; // Importa los estilos CSS

// Lista de imágenes para el carrusel
const carouselImages = [
  '/image/torneo1.1.jpg',
  '/image/gente jugando.jpg',
  '/image/cancha 2.jpg',
  '/image/cancha con balon.jpg',
];

const HomePage = () => {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentImageIndex((prevIndex) =>
        prevIndex === carouselImages.length - 1 ? 0 : prevIndex + 1
      );
    }, 3000); // Cambia la imagen cada 3 segundos

    return () => clearInterval(timer); // Limpia el intervalo al desmontar el componente
  }, []);

  return (
    <Layout>
      {/* Carrusel de imágenes */}
      <section className="carousel">
        <div
          className="carousel-images"
          style={{ transform: `translateX(-${currentImageIndex * 100}%)` }}>
          {carouselImages.map((src, index) => (
            <img
              key={index}
              src={src}
              alt={`Carousel image ${index + 1}`}
            />
          ))}
        </div>
      </section>

      {/* Sección de contenido con texto e imagen */}
      <section className="content-section">
        <div className="text">
          <h2 className="title">
            ¡¡Encuentra el mejor lugar para practicar deporte y formar parte de
            esta familia!!
          </h2>
          <p>
            Bienvenido a la escuela de formación deportiva La Calera Futsal,
            este es un espacio donde podrás encontrar información de tu interés
            respecto a Torneos, Convocatorias, Inscripciones y entrenamientos.
            Para encontrar información más detallada o ser parte de la escuela
            regístrate en el icono de la parte superior izquierda, elige tu rol
            y disfruta tu estancia en este sitio.
          </p>
        </div>
        <div className="image-box">
          <img
            src="/image/fotoescuela.png"
            alt="Imagen de la escuela"
          />
        </div>
      </section>

      {/* Sección con íconos circulares (ejemplo) */}
      <section className="icon-section">
        <div className="icon-box">
          <img
            src="/image/imagen mujeres.jpg"
            alt="Campeonas torneo Femenino"
          />
          <div className="icon-description">Campeonas Torneo Femenino</div>
        </div>
        <div className="icon-box">
          <img
            src="/image/torneo1.jpg"
            alt="Torneo Masculino"
          />
          <div className="icon-description">Torneos Masculinos</div>
        </div>
        <div className="icon-box">
          <img
            src="/image/entrenamiento.jpg"
            alt="Entrenamientos"
          />
          <div className="icon-description">Entrenamientos Especializados</div>
        </div>
      </section>
    </Layout>
  );
};

export default HomePage;
