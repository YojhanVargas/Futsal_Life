import React from 'react';
import Layout from '../../components/Layout/Layout';

const AcudienteDashboard = () => {
  return (
    <Layout>
      <div>
        <h1>Dashboard del Acudiente</h1>
        <p>
          Bienvenido, Acudiente. Aquí podrás ver el progreso y calendario de los
          jugadores a tu cargo.
        </p>
        {/* Más contenido específico del acudiente aquí */}
      </div>
    </Layout>
  );
};

export default AcudienteDashboard;
