import React from 'react';
import Layout from '../../components/Layout/Layout';
import './JugadorDashboard.css'; // Import the CSS file

const JugadorDashboard = () => {
  return (
    <Layout>
      <div className="jugador-dashboard">
        <h1>Dashboard del Jugador</h1>

        <div className="dashboard-content">
          <div className="dashboard-card">
            <h2>Mis Próximos Partidos</h2>
            <p>Consulta los detalles de tus próximos encuentros.</p>
            <ul>
              <li>
                <a href="#">Ver calendario de partidos</a>
              </li>
              <li>
                <a href="#">Confirmar asistencia</a>
              </li>
            </ul>
          </div>

          <div className="dashboard-card">
            <h2>Mis Convocatorias</h2>
            <p>
              Revisa si has sido convocado para los próximos partidos o eventos.
            </p>
            <ul>
              <li>
                <a href="#">Ver convocatorias activas</a>
              </li>
              <li>
                <a href="#">Notificar disponibilidad</a>
              </li>
            </ul>
          </div>

          <div className="dashboard-card">
            <h2>Mis Estadísticas</h2>
            <p>Consulta tu rendimiento y progreso.</p>
            <ul>
              <li>
                <a href="#">Ver goles anotados</a>
              </li>
              <li>
                <a href="#">Ver asistencias</a>
              </li>
              <li>
                <a href="#">Ver minutos jugados</a>
              </li>
            </ul>
          </div>

          <div className="dashboard-card">
            <h2>Plan de Entrenamiento</h2>
            <p>Consulta el plan de entrenamiento asignado.</p>
            <ul>
              <li>
                <a href="#">Ver próximos entrenamientos</a>
              </li>
              <li>
                <a href="#">Ejercicios recomendados</a>
              </li>
            </ul>
          </div>

          <div className="dashboard-card">
            <h2>Mi Perfil</h2>
            <p>Actualiza tu información personal y de contacto.</p>
            <ul>
              <li>
                <a href="#">Editar perfil</a>
              </li>
              <li>
                <a href="#">Ver información de acudiente (si aplica)</a>
              </li>
            </ul>
          </div>

          <div className="dashboard-card">
            <h2>Notificaciones</h2>
            <p>Revisa mensajes importantes del entrenador o del club.</p>
            <ul>
              <li>
                <a href="#">Ver mensajes no leídos</a>
              </li>
              <li>
                <a href="#">Historial de notificaciones</a>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default JugadorDashboard;
