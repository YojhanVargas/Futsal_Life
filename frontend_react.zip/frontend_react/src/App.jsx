import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext.jsx';
import Layout from "./components/layout/Layout.jsx"; 
import ProtectedRoute from './components/auth/ProtectedRoute.jsx';

// --- IMPORTACIONES DE PÁGINAS ---
import HomePage from "./pages/public/HomePage.jsx";
import LoginPage from "./pages/auth/LoginPage.jsx";
import RegisterPage from "./pages/auth/RegisterPage.jsx";
import EntrenadorDashboard from './pages/entrenador/EntrenadorDashboard.jsx';
import ListadosPage from './pages/entrenador/ListadosPage.jsx';
import JugadorDashboard from './pages/jugador/JugadorDashboard.jsx';
import AcudienteDashboard from './pages/acudiente/AcudienteDashboard.jsx';
import ConvocatoriasPage from './pages/shared/ConvocatoriasPage.jsx';
import CategoriasPage from './pages/shared/CategoriasPage.jsx';
import CalendarioPage from './pages/shared/CalendarioPage.jsx';
import ProfilePage from './pages/shared/ProfilePage.jsx';
import NotFoundPage from './pages/system/NotFoundPage.jsx';

// --- COMPONENTE DE RUTAS OPTIMIZADO ---
const AppRoutes = () => {
  const { isLoading } = useAuth();
    if (isLoading) {
      return <div>Cargando aplicación...</div>;
    }

  return (
    <Routes>
      {/* --- RUTAS PÚBLICAS --- */}
      <Route path="/" element={ <Layout><HomePage /></Layout> } />
      <Route path="/login" element={ <Layout showNavigation={false}><LoginPage /></Layout> } />
      <Route path="/register" element={ <Layout showNavigation={false}><RegisterPage /></Layout> } />

      {/* --- ÁREA PARA TODOS LOS USUARIOS AUTENTICADOS --- */}
      <Route element={<ProtectedRoute allowedRoles={['entrenador', 'jugador', 'acudiente']} />}>
        {/* Rutas compartidas para todos los roles */}
        <Route path="/perfil" element={<ProfilePage />} />
        <Route path="/convocatorias" element={<ConvocatoriasPage />} />
        <Route path="/calendario" element={<CalendarioPage />} />
        <Route path="/categorias" element={<CategoriasPage />} />
        
        {/* Rutas específicas para ENTRENADOR */}
        <Route element={<ProtectedRoute allowedRoles={['entrenador']} />}>
          <Route path="/entrenador" element={<EntrenadorDashboard />} />
          <Route path="/listados" element={<ListadosPage />} />
        </Route>

        {/* Rutas específicas para JUGADOR */}
        <Route element={<ProtectedRoute allowedRoles={['jugador']} />}>
          <Route path="/jugador" element={<JugadorDashboard />} />
        </Route>

        {/* Rutas específicas para ACUDIENTE */}
        <Route element={<ProtectedRoute allowedRoles={['acudiente']} />}>
          <Route path="/acudiente" element={<AcudienteDashboard />} />
        </Route>
      </Route>

      {/* --- PÁGINA NO ENCONTRADA --- */}
      <Route path="*" element={ <Layout><NotFoundPage /></Layout> } />
    </Routes>
  );
};

// --- COMPONENTE PRINCIPAL (SIN CAMBIOS) ---
const App = () => {
  return (
    <Router>
      <AuthProvider>
        <AppRoutes />
      </AuthProvider>
    </Router>
  );
};

export default App;