import apiClient from './api';

export const authService = {
  login: async (credentials) => {
    try {
      const response = await apiClient.post('/auth/login', credentials);
      return response.data;
    } catch (error) {
      console.error('Error en login:', error.response?.data || error.message);
      throw error;
    }
  },
  register: async (userData) => {
    try {
      const response = await apiClient.post('/auth/register', userData);
      return response.data;
    } catch (error) {
      console.error(
        'Error en registro:',
        error.response?.data || error.message
      );
      throw error;
    }
  },
  getProfile: async () => {
    try {
      const response = await apiClient.get('/perfil');
      return response.data;
    } catch (error) {
      console.error(
        'Error obteniendo perfil:',
        error.response?.data || error.message
      );
      throw error;
    }
  },
  updateProfile: async (profileData) => {
    try {
      const response = await apiClient.put('/perfil', profileData);
      return response.data;
    } catch (error) {
      console.error(
        'Error actualizando perfil:',
        error.response?.data || error.message
      );
      throw error;
    }
  },
};
